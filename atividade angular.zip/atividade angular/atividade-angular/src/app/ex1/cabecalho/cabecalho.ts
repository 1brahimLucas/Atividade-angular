import { Component } from '@angular/core';

@Component({
  selector: 'app-cabecalho',
  templateUrl: './cabecalho.html',
  styleUrl: './cabecalho.css',
})
export class Cabecalho {
  nome = 'Ibrahim Lucas';
  descricao = 'Estudante de Desenvolvimento de Sistemas.';
}