import { Component } from '@angular/core';

@Component({
  selector: 'app-area-cards',
  templateUrl: './area-cards.html',
  styleUrl: './area-cards.css',
})
export class AreaCards {
  projetos = [
    { titulo: 'Sobre mim', texto: 'Me chamo Ibrahim, moro em Blumenau e estudo desenvolvimento de sistemas. Estou aprendendo Angular e gosto de criar sites e resolver problemas com código. Busco uma oportunidade de estágio para crescer na área.' },
    { titulo: 'Formação', texto: 'Cursando +Devstoblu no Senai' },
    { titulo: 'Habilidades', texto: 'Java, Python, Github' },
    { titulo: 'Contato', texto: 'ibrahimlucas2304@gmail.com' },
  ];
}