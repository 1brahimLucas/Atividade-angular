import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AreaCards } from './area-cards';

describe('AreaCards', () => {
  let component: AreaCards;
  let fixture: ComponentFixture<AreaCards>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AreaCards],
    }).compileComponents();

    fixture = TestBed.createComponent(AreaCards);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
