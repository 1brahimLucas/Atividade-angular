import { Component } from '@angular/core';
import { CabecalhoPagina } from '../../ex2/cabecalho-pagina/cabecalho-pagina';
import { MenuNavegacao } from '../../ex2/menu-navegacao/menu-navegacao';
import { ConteudoPrincipal } from '../../ex2/conteudo-principal/conteudo-principal';
import { RodapePagina } from '../../ex2/rodape-pagina/rodape-pagina';

@Component({
  selector: 'app-ex2-page',
  imports: [CabecalhoPagina, MenuNavegacao, ConteudoPrincipal, RodapePagina],
  templateUrl: './ex2-page.html',
  styleUrl: './ex2-page.css',
})
export class Ex2Page {}