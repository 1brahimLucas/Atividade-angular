import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Ex2Page } from './ex2-page';

describe('Ex2Page', () => {
  let component: Ex2Page;
  let fixture: ComponentFixture<Ex2Page>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Ex2Page],
    }).compileComponents();

    fixture = TestBed.createComponent(Ex2Page);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
