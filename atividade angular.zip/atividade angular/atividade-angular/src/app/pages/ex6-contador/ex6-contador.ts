import { Component } from '@angular/core';

@Component({
  selector: 'app-ex6-contador',
  templateUrl: './ex6-contador.html',
})
export class Ex6Contador {
  contador = 0;

  incrementar() {
    this.contador = this.contador >= 10 ? 0 : this.contador + 1;
  }

  zerar() {
    this.contador = 0;
  }
}