import { Component } from '@angular/core';
import { Cabecalho } from '../../ex1/cabecalho/cabecalho';
import { AreaCards } from '../../ex1/area-cards/area-cards';
import { Rodape } from '../../ex1/rodape/rodape';

@Component({
  selector: 'app-ex1-page',
  imports: [Cabecalho, AreaCards, Rodape],
  templateUrl: './ex1-page.html',
})
export class Ex1Page {}