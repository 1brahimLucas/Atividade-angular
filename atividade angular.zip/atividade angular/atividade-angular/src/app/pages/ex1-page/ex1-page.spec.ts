import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Ex1Page } from './ex1-page';

describe('Ex1Page', () => {
  let component: Ex1Page;
  let fixture: ComponentFixture<Ex1Page>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Ex1Page],
    }).compileComponents();

    fixture = TestBed.createComponent(Ex1Page);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
