import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Ex3Intro } from './ex3-intro';

describe('Ex3Intro', () => {
  let component: Ex3Intro;
  let fixture: ComponentFixture<Ex3Intro>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Ex3Intro],
    }).compileComponents();

    fixture = TestBed.createComponent(Ex3Intro);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
