import { Component } from '@angular/core';

@Component({
  selector: 'app-ex3-intro',
  templateUrl: './ex3-intro.html',
})
export class Ex3Intro {
  nome = 'Ibrahim Rodrigues';
  idade = 18;
  cidade = 'Blumenau';
  curso = '+Devstoblu';
}