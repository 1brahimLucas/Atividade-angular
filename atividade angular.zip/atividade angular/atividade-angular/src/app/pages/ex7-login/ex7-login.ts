import { Component } from '@angular/core';

@Component({
  selector: 'app-ex7-login',
  templateUrl: './ex7-login.html',
})
export class Ex7Login {
  logado = false;

  alternar() {
    this.logado = !this.logado;
  }
}