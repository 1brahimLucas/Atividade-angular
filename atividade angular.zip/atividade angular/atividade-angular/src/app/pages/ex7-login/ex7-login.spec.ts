import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Ex7Login } from './ex7-login';

describe('Ex7Login', () => {
  let component: Ex7Login;
  let fixture: ComponentFixture<Ex7Login>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Ex7Login],
    }).compileComponents();

    fixture = TestBed.createComponent(Ex7Login);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
