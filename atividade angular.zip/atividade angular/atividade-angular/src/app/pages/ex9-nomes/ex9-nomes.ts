import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-ex9-nomes',
  imports: [FormsModule],
  templateUrl: './ex9-nomes.html',
})
export class Ex9Nomes {
  nome = '';
  nomes: string[] = [];

  adicionar() {
    const n = this.nome.trim();
    if (n) {
      this.nomes.push(n);
      this.nome = '';
    }
  }
}