import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Ex9Nomes } from './ex9-nomes';

describe('Ex9Nomes', () => {
  let component: Ex9Nomes;
  let fixture: ComponentFixture<Ex9Nomes>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Ex9Nomes],
    }).compileComponents();

    fixture = TestBed.createComponent(Ex9Nomes);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
