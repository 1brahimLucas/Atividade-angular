import { Component } from '@angular/core';
import { Pessoa } from '../../models/pessoa';

@Component({
  selector: 'app-ex4-pessoas',
  templateUrl: './ex4-pessoas.html',
})
export class Ex4Pessoas {
  pessoa1: Pessoa = { nome: 'Ana Silva', sexo: 'Feminino', dataNascimento: '10/05/2000', estadoCivil: 'Solteira' };
  pessoa2: Pessoa = { nome: 'João Souza', sexo: 'Masculino', dataNascimento: '22/11/1995', estadoCivil: 'Casado' };
}