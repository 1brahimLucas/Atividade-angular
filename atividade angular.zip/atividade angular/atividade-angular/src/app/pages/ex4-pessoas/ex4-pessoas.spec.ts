import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Ex4Pessoas } from './ex4-pessoas';

describe('Ex4Pessoas', () => {
  let component: Ex4Pessoas;
  let fixture: ComponentFixture<Ex4Pessoas>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Ex4Pessoas],
    }).compileComponents();

    fixture = TestBed.createComponent(Ex4Pessoas);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
