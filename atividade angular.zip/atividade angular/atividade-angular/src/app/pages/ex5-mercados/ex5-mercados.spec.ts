import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Ex5Mercados } from './ex5-mercados';

describe('Ex5Mercados', () => {
  let component: Ex5Mercados;
  let fixture: ComponentFixture<Ex5Mercados>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Ex5Mercados],
    }).compileComponents();

    fixture = TestBed.createComponent(Ex5Mercados);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
