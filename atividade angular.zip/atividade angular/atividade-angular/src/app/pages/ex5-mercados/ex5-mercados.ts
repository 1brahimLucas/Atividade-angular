import { Component } from '@angular/core';
import { Mercado } from '../../models/mercado';

@Component({
  selector: 'app-ex5-mercados',
  templateUrl: './ex5-mercados.html',
})
export class Ex5Mercados {
  unidadeDeBlumenau: Mercado = { nome: 'Unidade de Blumenau', macasVendidasAno: 12000, precoMaca: 5.5, laranjasVendidasAno: 9000, precoLaranja: 4.2 };
  unidadeDeJoinville: Mercado = { nome: 'Unidade de Joinville', macasVendidasAno: 15000, precoMaca: 5.8, laranjasVendidasAno: 11000, precoLaranja: 4.5 };
  unidadeDeFlorianopolis: Mercado = { nome: 'Unidade de Florianópolis', macasVendidasAno: 10000, precoMaca: 6.0, laranjasVendidasAno: 8000, precoLaranja: 4.8 };

  mercados: Mercado[] = [this.unidadeDeBlumenau, this.unidadeDeJoinville, this.unidadeDeFlorianopolis];
}