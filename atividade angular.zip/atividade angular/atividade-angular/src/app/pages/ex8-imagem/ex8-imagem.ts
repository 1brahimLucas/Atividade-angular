import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-ex8-imagem',
  imports: [FormsModule],
  templateUrl: './ex8-imagem.html',
})
export class Ex8Imagem {
  urlJava = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg';
  url = this.urlJava;

  voltarJava() {
    this.url = this.urlJava;
  }
}