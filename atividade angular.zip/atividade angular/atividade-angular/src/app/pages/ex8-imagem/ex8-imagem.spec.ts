import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Ex8Imagem } from './ex8-imagem';

describe('Ex8Imagem', () => {
  let component: Ex8Imagem;
  let fixture: ComponentFixture<Ex8Imagem>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Ex8Imagem],
    }).compileComponents();

    fixture = TestBed.createComponent(Ex8Imagem);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
