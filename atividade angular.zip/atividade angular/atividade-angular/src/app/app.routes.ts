import { Routes } from '@angular/router';
import { Ex1Page } from './pages/ex1-page/ex1-page';
import { Ex2Page } from './pages/ex2-page/ex2-page';
import { Ex3Intro } from './pages/ex3-intro/ex3-intro';
import { Ex4Pessoas } from './pages/ex4-pessoas/ex4-pessoas';
import { Ex5Mercados } from './pages/ex5-mercados/ex5-mercados';
import { Ex6Contador } from './pages/ex6-contador/ex6-contador';
import { Ex7Login } from './pages/ex7-login/ex7-login';
import { Ex8Imagem } from './pages/ex8-imagem/ex8-imagem';
import { Ex9Nomes } from './pages/ex9-nomes/ex9-nomes';

export const routes: Routes = [
  { path: '', redirectTo: 'ex1', pathMatch: 'full' },
  { path: 'ex1', component: Ex1Page },
  { path: 'ex2', component: Ex2Page },
  { path: 'ex3', component: Ex3Intro },
  { path: 'ex4', component: Ex4Pessoas },
  { path: 'ex5', component: Ex5Mercados },
  { path: 'ex6', component: Ex6Contador },
  { path: 'ex7', component: Ex7Login },
  { path: 'ex8', component: Ex8Imagem },
  { path: 'ex9', component: Ex9Nomes },
];