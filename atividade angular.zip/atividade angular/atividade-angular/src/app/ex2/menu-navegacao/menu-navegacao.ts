import { Component } from '@angular/core';

@Component({
  selector: 'app-menu-navegacao',
  templateUrl: './menu-navegacao.html',
  styleUrl: './menu-navegacao.css',
})
export class MenuNavegacao {}