import { Component } from '@angular/core';

@Component({
  selector: 'app-cabecalho-pagina',
  templateUrl: './cabecalho-pagina.html',
  styleUrl: './cabecalho-pagina.css',
})
export class CabecalhoPagina {}