import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ConteudoPrincipal } from './conteudo-principal';

describe('ConteudoPrincipal', () => {
  let component: ConteudoPrincipal;
  let fixture: ComponentFixture<ConteudoPrincipal>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ConteudoPrincipal],
    }).compileComponents();

    fixture = TestBed.createComponent(ConteudoPrincipal);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
