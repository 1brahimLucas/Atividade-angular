import { Component } from '@angular/core';

@Component({
  selector: 'app-conteudo-principal',
  templateUrl: './conteudo-principal.html',
  styleUrl: './conteudo-principal.css',
})
export class ConteudoPrincipal {}