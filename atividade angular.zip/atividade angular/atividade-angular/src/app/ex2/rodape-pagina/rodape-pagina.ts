import { Component } from '@angular/core';

@Component({
  selector: 'app-rodape-pagina',
  templateUrl: './rodape-pagina.html',
  styleUrl: './rodape-pagina.css',
})
export class RodapePagina {}