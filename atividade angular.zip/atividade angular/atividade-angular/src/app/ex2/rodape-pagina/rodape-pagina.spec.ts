import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RodapePagina } from './rodape-pagina';

describe('RodapePagina', () => {
  let component: RodapePagina;
  let fixture: ComponentFixture<RodapePagina>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RodapePagina],
    }).compileComponents();

    fixture = TestBed.createComponent(RodapePagina);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
