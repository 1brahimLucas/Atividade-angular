export interface Mercado {
  nome: string;
  macasVendidasAno: number;
  precoMaca: number;
  laranjasVendidasAno: number;
  precoLaranja: number;
}